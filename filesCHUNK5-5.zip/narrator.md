# Actor — Narrator (output seat)

**Appears in:** step 5 · **Decisions:** A6

## Role

Renders prose for the player from the **post-beat perception payload**. The output side of the loop's
LLM. **Presentation only — writes nothing to canon** (I-6); not logged for replay determinism.

## What it sees

Only the player's perceptions (the wall; ADR-020, no omniscient pass). It never sees hidden canon truth.

## Key property (A6)

The narrator renders what the player **perceived**, which may be the **visible** aspect of a
performed/faked expression or a deception — not the hidden canon. It does not "lie"; it honestly renders
an honestly-generated perception. The lie, when there is one, lives in the world (the gate recorded a
visible aspect that differs from the truth).

## Note on determinism

Narration may vary run-to-run; that does **not** threaten replay. Replay rebuilds the world from the
committed event log, not from prose (Q1/I-1). This is the crux of the Chunk-5 operator gate (Q3).
