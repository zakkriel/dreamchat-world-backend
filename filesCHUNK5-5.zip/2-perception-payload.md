# Step 2 — Perception payload (gather what the viewer perceives)

**Driven by:** [Engine](../actors/engine-gate.md) (via the wall) · consumed by the [Decomposer](../actors/decomposer.md) · **Decisions:** A2

## What happens

Before the text is interpreted, the backend builds the viewer's perception payload:

```sql
SELECT content FROM fn_visible_perceptions(world, viewer) ORDER BY acquired_tick
```

This is **the wall** (B-1 / I-3). It returns only what *this viewer* perceives — never canon, never
another actor's view, never omniscient state. **This is the only context the interpreter gets.**

## Why it matters

The payload is what the text resolves **against**. "tell her about the note" must bind "her" and "the
note" to something in these perceptions. If you never perceived the note, there is nothing to bind to.

## The gap (A2)

Shipped payload is a flat list of prose strings (`PerceptionPayload{ Lines []string }`):
- **No entity ids** ride along → "her" can't bind to a stable id.
- **No co-presence list** → "who can I address" is computed later in the gate (`fn_actors_at`) and never
  shown to the interpreter.
- **No location / scene frame** → the interpreter must reconstruct "you are at X; present: A, B" from
  prose.

**Decision (A2):** widen to a structured, still-perception-bound payload carrying current location,
co-present actors (id + perceived name), and reference-resolvable entities (id + perceived name + kind).
All through the wall; nothing unperceived leaks. This is also the input half of A5 (the interpreter can
only emit a reference token if the payload gives it the handles).

## Current vs intended

| | Shipped | Intended (5.5) |
|---|---|---|
| Shape | `Lines []string` | structured handles + (optional) prose lines |
| Co-presence | not surfaced | included (id + perceived name) |
| Location frame | absent | included |
| Source | `fn_visible_perceptions` | unchanged (wall stays the source) |
