# Hosting & Setup — Loop Seats

**Status:** recommendation 2026-06-20 — verify current host capabilities before committing (fast-moving).
Companion to [`model-survey.md`](model-survey.md). Enabled by the per-seat bridge (ADR-P018).

## Headline: two model families, not four seat-models

| Family | Serves | Why | Candidates (permissive) |
|---|---|---|---|
| **Reasoning + structured** | decompose · cognition · resolve | one capable model, different prompts/grammars; schema enforced by constrained decoding | Qwen3 32B / Mistral Small 4 (Apache); resolve can escalate to DeepSeek-R1 / GLM-5 |
| **Prose / RP** | narrate | "alive/premium" prose; no schema needed | Hermes 3 70B, Euryale 70B, Cydonia 24B, Midnight Miqu |

## The tension that drives hosting: permissive **and** structured output

Only **decompose** needs both, and they pull apart:
- Permissive RP routes (OpenRouter, RP hosts) often **lack** grammar/structured support → OK for narrate, not decompose.
- Cleanest structured-output hosts apply **content policies** → risky for decompose, which must *read* explicit input.
- **Resolution:** self-host the decompose model on **vLLM/SGLang** with `guided_json` (XGrammar backend) — you own the grammar **and** the content policy, schema valid by construction, no per-token upcharge.

## Stage 0 — dev / now (rent, move fast) — **NO POD**

Settled 2026-06-20: the permissive hosts do strict `json_schema` structured output on DeepSeek/Qwen
(DeepInfra docs show `response_format: json_schema, strict: true` on DeepSeek-V3; all major DeepSeek
providers support JSON mode). So the only reason to self-host decompose (the schema leash) is gone for
Stage 0 → **100% API, zero GPU.**

| Seat | Model | Host |
|---|---|---|
| Decompose | `mistralai/Mistral-Small-24B-Instruct-2501` ($0.05/$0.08) — `json_schema` strict ✓ | DeepInfra |
| Cognition | `deepseek-ai/DeepSeek-V4-Flash` ($0.10/$0.20) | DeepInfra |
| Resolve | `DeepSeek-V4-Flash` normally; escalate `deepseek-ai/DeepSeek-R1-0528` ($0.50/$2.15) for hard calls | DeepInfra |
| Narrate | `sao10k/l3.3-euryale-70b` ✓ | OpenRouter permissive route |

**Smoke test 2026-06-21 — all three seats PASS:** decompose returns schema-locked JSON on Mistral-24B;
DeepSeek reasoning reachable; Euryale generates mature content, no refusal. Stage-0 access proven.

- All OpenAI-compatible → bridge drivers differ only by base URL + model + key.
- **Content policy is only a narrate concern** — decompose/cognition/resolve *parse*, they don't
  *generate* explicit prose; verify the narrate route is permissive and that the decompose host tolerates
  explicit *input* (low bar).
- Credits to chase: Together Startup ($50K), RunPod Startup (free H100 hours).
- The RunPod vLLM runbook (`runpod-stage0-runbook.md`) is now the **fallback** — only if a host's
  structured output or content policy fails in practice.

## Stage 0 (original pod plan — now fallback only)

## Stage 1 — scale / sovereignty

- Consolidate all seats onto own GPUs (vLLM/SGLang): content control + constrained decoding + cost control.
- Trigger: the cost-model crossover (hundreds of users on pure cost) **or** content-sovereignty risk (a host revoking your content), whichever comes first.
- **Sizing:** 70B BF16 ≈ 140 GB VRAM → 2×H100 (tensor-parallel) or fp8 on 1×H100. A 7–32B reasoning model fits one card. Realistically **1–2 H100-class GPUs**, two models, batched.

## Build-now items (so the swap isn't a wall)

- **Constrained decoding for decompose from day one** (A9) — vLLM/SGLang `guided_json`, XGrammar.
- **Keep every driver OpenAI-compatible** behind the bridge so host swaps are config, not code.
- **Early permissive narrate smoke-test** (A9) — de-risk hosting/format/latency before phase 2.

## Hard line (unchanged, model/host-independent)

No minors, no non-consensual real-person depictions → governance/classification gate, before any provider call.
