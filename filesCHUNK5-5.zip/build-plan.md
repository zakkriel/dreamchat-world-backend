# Build Plan — "A Tavern That's Hiding Something" (Chunk 5.5 vertical slice)

**Status:** READY TO BUILD (2026-06-21) · Stage-0 access proven (smoke test green) · content locked
(1c/2c/3c). **Read first:** [`next-vertical-slice.md`](next-vertical-slice.md) (the what/why),
[`decisions.md`](decisions.md) A1–A10 (the contracts), then this (the how).

**Gate:** done = it **feels alive when played** (the four felt properties in §7), not green CI (A7).

---

## 0. For the building agent (read before touching code)

- ONE worktree, ONE PR, built and judged **as a scene** — not as three separate SPECs.
- The engine set (`docs/30_architecture/canon_engine/`) is **FROZEN** (D-9): engine changes need a new
  ADR **with running-code evidence**. This slice amends the **Chunk-5 thin slice**, not frozen canon.
- Keep the **whole scene** in context. Do not re-slice it into horizontal layers — that's the exact
  failure A7 corrects.
- **Phase 1 first** (A9): build + validate mechanics on **clean content** with frontier/fake drivers.
  Only then **Phase 2**: swap to the confirmed permissive models + real content.
- Keys from env, never hardcoded. All seats are OpenAI-compatible.

## 1. The stack to wire (Stage 0 — all-API, confirmed green 2026-06-21)

| Seat | Model id | Host | Note |
|---|---|---|---|
| Decompose | `mistralai/Mistral-Small-24B-Instruct-2501` | DeepInfra | `json_schema` strict = the leash; **confirmed** |
| Cognition | `deepseek-ai/DeepSeek-V4-Flash` | DeepInfra | cheap reasoning ($0.10/$0.20) |
| Resolve | `DeepSeek-V4-Flash`; escalate `deepseek-ai/DeepSeek-R1-0528` for hard calls | DeepInfra | reasoning; off the hot path (30s) |
| Narrate | `sao10k/l3.3-euryale-70b` | OpenRouter | mature prose; **confirmed** |

Each driver = base URL + model + key behind the existing seat bridge (ADR-P018). No GPU, no pod.

## 2. What to build (the deltas from shipped Chunk-5)

1. **Bridge drivers (4).** OpenAI-compatible drivers for the four seats above. Build a **fake** driver per
   seat first (deterministic canned output) so the loop runs end-to-end before any model is involved,
   then the real HTTP driver. Decompose driver passes the `beat_chain` schema as `response_format:
   json_schema strict`.
2. **A2 — enriched perception payload.** Widen the flat `PerceptionPayload{Lines[]}` to a structured,
   still perception-bound payload: current location, co-present actors (id + perceived-name),
   reference-resolvable entity handles. Through the wall — nothing unperceived leaks.
3. **A5 — reference tokens, not raw ids.** Model emits a name/handle; the **engine** resolves token→id
   deterministically and rejects ambiguous/unknown. The model is never in identity-authority.
4. **A3 — generic `AttributeChanged` keystone.** Build the generic attribute-change event (novelty in
   data, not a new hardcoded verb) carrying the **SPEC-016 visible/hidden flag**. This is the spine that
   carries both Mara's recognition (hidden) and her composure (state). Build this **before** any more
   bespoke verbs.
5. **SPEC-016 (min) — visible ≠ hidden.** Mara has `recognizes_player` with **hidden canon = true** and a
   **visible aspect = stranger**. Perception surfaces the visible; canon keeps the hidden.
6. **SPEC-013 (min) — real resolve.** Intimidation is **adjudicated from state** (see §5), outcome ≠
   intent. Success → recognition **surfaces via the normal AttributeChanged perception update** (no
   bespoke reveal). Failure → composure holds + a consequence (`disposition := wary/hostile`).
7. **SPEC-012 (min) — the world acts.** Jonas fires an **autonomous** event on the clock: passes Mara
   something, then leaves. Witnessed **only** if the player is co-present and attending.
8. **Step-5 narrate fix.** Feed the narrator the `halt_reason`, the resolve **outcome**, and a "what
   changed this beat" delta — so pushback is **communicated**, not just computed.

## 3. The state-grounding rule (learned from the smoke test — do not skip)

The reasoning seat gave **opposite** answers across two runs on "is Mara easier or harder to intimidate
once Jonas leaves," because the prompt never defined their relationship — so it **confabulated** one.

**Rule:** the interlock direction lives in **canon/state**, never in the model. Seed
`jonas.role_to_mara = protector` → his leaving **lowers** `mara.composure`. Resolve reasons **from**
given state; it never invents relationships. Otherwise "the world pushes back" is a coin flip wearing a
reason.

## 4. Scene seed data

- **Tavern** (one flat place).
- **Mara:** `recognizes_player = true` (**hidden**; visible = stranger), `composure = <N>`,
  `protected_by = Jonas`, `disposition = neutral`.
- **Jonas:** scheduled autonomous beat = {hand item to Mara, then exit} fired on the clock.
- **Player.**

## 5. Resolve logic (SPEC-013 min) — concrete

- **Inputs (all from state):** `mara.composure`, `jonas_present?`, `player_leverage`.
- **Adjudication:** effective resistance = `composure` boosted while `jonas_present`, lowered once he's
  gone. Compare against the intimidation pressure.
  - **Success** → `AttributeChanged(mara.recognizes_player.visible := true)` — recognition surfaces
    through the ordinary perception update.
  - **Failure** → composure holds + `AttributeChanged(mara.disposition := wary|hostile)`.
- **The interlock:** Jonas gone ⇒ lower effective resistance ⇒ success more likely. The world's
  autonomous action **changes the player's odds** — felt, not decorative.

## 6. Build order (keep it always-runnable, vertical)

1. Bridge drivers (fakes → real) — loop runs end-to-end on clean content.
2. A2 payload + A5 token resolution — references resolve deterministically.
3. A3 `AttributeChanged` keystone — the generic verb.
4. SPEC-016 visible/hidden on `mara.recognizes_player` — perception shows "stranger."
5. SPEC-013 resolve (intimidate) — failable, **state-grounded** (§3, §5).
6. SPEC-012 Jonas autonomous exit + handoff — the world moves without the player.
7. Step-5 narrate fix — halt/outcome/delta fed to the narrator.
8. Wire the interlock (Jonas exit → composure) and **play it**.

## 7. The play-test gate (Phase 1 clean → Phase 2 permissive)

Play the scene. The four felt properties:
- **(a)** something happened you didn't cause — Jonas left on his own.
- **(b)** something you tried didn't just succeed — intimidation can fail.
- **(c)** you were shown an appearance that wasn't the truth — "stranger" while canon holds "knows you."
- **(d)** the narrator **told** you the pushback — halt/outcome surfaced in prose.

**Done = all four AND it made an interesting beat.** Then swap to the confirmed permissive models
(Mistral-24B / DeepSeek-V4-Flash / Euryale) and re-test with real content (Phase 2). A green suite is
necessary, not sufficient.

---

**Rules anchor:** `docs/00_strategy/06_rules_register.md` is law. Nothing here amends frozen canon; it
amends the Chunk-5 thin slice and the write-side bridge contract (`mvp_slice_and_bridge.md §4.2`).
