# RunPod Serverless — Stage-0 Decompose Endpoint (runbook)

**Status:** ready to execute 2026-06-20. Self-host the **decompose** model on RunPod serverless,
scale-to-zero. Companion to [`hosting-and-setup.md`](hosting-and-setup.md). Verify exact console labels
against current RunPod docs — they move.

## 0. What you do vs what's here

- **You:** create the RunPod account, add credit, deploy the endpoint, copy the **Endpoint ID** + an
  **API key**. (Account / payment / auth are yours — not something I do for you.)
- **Here:** exact model · GPU · env · worker settings, the call from your Go bridge, and the warm-up
  pattern so the one cold start hides behind a loading screen.

## 1. Model (decompose — phase-1 clean content)

- **Default:** `Qwen/Qwen3-8B` — Apache, ungated, strong, vLLM-supported. **Alt:**
  `mistralai/Ministral-8B-Instruct-2410`.
- The **grammar carries correctness**, so 8B is plenty for dev. Phase-2 (permissive) = swap `MODEL_NAME`
  to a permissive/uncensored variant; same endpoint.

## 2. Deploy (RunPod console)

1. **Serverless → deploy the official vLLM worker** (RunPod Hub → search "vLLM", latest version; image
   is `runpod/worker-v1-vllm:<latest-stable-cuda>`).
2. **Model** field → `Qwen/Qwen3-8B`.
3. **GPU** → a **24 GB** tier (RTX 4090 / L4 / A5000) — fits an 8B comfortably and is the cheap tier.
4. **Workers** → **Min 0** (flex / scale-to-zero), **Max 1** (dev). Do **not** set Min ≥ 1 in dev — that
   defeats scale-to-zero.
5. **Idle timeout** → **120–300 s** (keeps the worker warm between beats within a session).
6. **FlashBoot** → on (faster revival), and **attach a Network Volume** for the model cache so a
   scaled-to-zero worker reloads from cache instead of re-downloading.
7. Set env (below) → **Create** → copy the **Endpoint ID**.

## 3. Environment variables

```
MODEL_NAME=Qwen/Qwen3-8B
MAX_MODEL_LEN=8192
DTYPE=bfloat16
GPU_MEMORY_UTILIZATION=0.90
MAX_NUM_SEQS=16
BASE_PATH=/runpod-volume        # model cache persists across scale-to-zero
# HF_TOKEN=...                   # only if you pick a gated model
```

## 4. Cold-start tuning (respect the 30 s rule)

- **Network-volume cache** → cold start = reload into VRAM, not re-download.
- **Warm-up ping** at session open (§6) → the single cold start hides behind "entering the world."
- **Idle timeout ≥ your inter-beat gap** → one cold start per session, warm thereafter.

## 5. Call it from the bridge (OpenAI-compatible, schema = the leash)

`POST https://api.runpod.ai/v2/<ENDPOINT_ID>/openai/v1/chat/completions`
`Authorization: Bearer <RUNPOD_API_KEY>`

```go
body := map[string]any{
  "model": "Qwen/Qwen3-8B",
  "messages": []map[string]string{
    {"role": "system", "content": decomposeSystemPrompt},
    {"role": "user",   "content": playerText + "\n\n" + perceptionPayload},
  },
  "temperature": 0,
  "max_tokens": 512,
  // THE LEASH: constrained decoding to beat_chain/1
  "response_format": map[string]any{
    "type": "json_schema",
    "json_schema": map[string]any{"name": "beat_chain", "schema": beatChainSchema},
  },
  // vLLM-native alternative if the worker build prefers it:
  // "guided_json": beatChainSchema,   // pass as extra body field
}
// POST to endpointURL with Bearer RUNPOD_API_KEY; decode choices[0].message.content as the chain.
```

## 6. Warm-up ping (fire on session open)

```go
// Trigger the cold start before the first real beat. Ignore the output.
func WarmUp(ctx context.Context, endpointURL, apiKey string) {
  body := map[string]any{
    "model": "Qwen/Qwen3-8B",
    "messages": []map[string]string{{"role": "user", "content": "ping"}},
    "max_tokens": 1,
  }
  _ = postJSON(ctx, endpointURL, apiKey, body) // best-effort; warms the worker
}
```

## 7. Bridge wiring

This is just another **OpenAI-compatible driver** behind the seat bridge (ADR-P018): base URL + model +
key. The fake/Anthropic drivers already prove the seam; the RunPod driver is the third. Phase-2 model
swap = change `MODEL_NAME` (or point the decompose seat at a different endpoint) — no engine change.

## Caveats (verify before relying)

- Confirm the current console labels (FlashBoot toggle, idle-timeout field) and that your worker version
  accepts `response_format: json_schema`; if not, use vLLM's `guided_json` extra body field.
- This is the **phase-1 clean-content** decompose model; swap to a permissive variant for phase 2.
- Keep **Max workers = 1** and **Min = 0** in dev, or you'll pay for idle GPUs.
