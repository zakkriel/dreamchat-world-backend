# Model Survey — Loop Seats (text & reasoning)

**Status:** research snapshot 2026-06-20 — fast-moving, **verify before committing**. Reference for the
per-seat routing decision; not a lock.

## The reframe: route by capability *type*, not just cost

The field splits on a tradeoff the RP/writing community states plainly: the "smart" instruction-following
reasoning models (Qwen3.5, DeepSeek-R1, GLM-5) follow rules well but *write* like corporate assistants;
the prose/RP fine-tunes (Midnight Miqu, Hermes 3, Euryale) write like novelists but follow strict
instructions worse. So the seats want **different model families**, not just different price tiers:

| Seat | Needs | Candidate models (permissive) | Notes |
|---|---|---|---|
| **Decompose** | reasoning + **strict schema** | Qwen3.5 (Apache), Mistral Small 4/Magistral (Apache), GLM-5.1 (MIT), DeepSeek-R1-distill 32B | Schema enforced by **constrained decoding at the host**, not model compliance — so a mid open model is fine. Don't run a heavy CoT model here (latency). |
| **Resolve / adjudication** (SPEC-013) | **heaviest reasoning** | DeepSeek-R1 / V4, Qwen3.5 397B-reasoning, GLM-5 reasoning, Magistral | Only fires on *uncertain* actions, not every beat → you can afford a slower reasoning model here. |
| **Cognition** (NPC decide) | mid reasoning, perception-bound | Qwen3.5 27–32B, Mistral Small 4, GLM-5.1, MiniMax M2.7 | One director call (per-NPC partitioned context). |
| **Narrate** | **prose quality**, permissive | Hermes 3 (Llama 3.3), Midnight Miqu 1.5, Sao10K Euryale 70B, TheDrummer Cydonia 24B, EVA Qwen 2.5 | The "alive/premium" feel lives here. "Smarter" ≠ better prose. |

## Permissiveness — three tiers

1. **Base instruct + a good system prompt** (Llama 3.3 70B, Qwen3 32B) already handles *most* mature
   content. Many use cases need no special model.
2. **Uncensored / RP fine-tunes** (Hermes 3, Dolphin series, Euryale, Cydonia, EVA-Qwen, Midnight Miqu)
   for *persistent* explicit/dark content without arbitrary refusals.
3. **Self-host** open weights → full policy control (content sovereignty).

**Hosted-permissive without a GPU:** OpenRouter routes serve uncensored models via API today
(e.g. Euryale 70B, Cydonia 24B, Lunaris 8B). So permissive ≠ "must self-host immediately."

## Two traps to avoid

- **Official APIs of open models censor.** DeepSeek's and Qwen's *hosted APIs* moderate (DeepSeek's is
  heavily monitored; Qwen's official instruct self-censors RP). The permissive path is the **open
  weights** — via a permissive host or self-hosted — not those vendors' own endpoints.
- **License (company is Uruguay/Brazil, not EU):** the **Llama** license's *EU-domicile restriction*
  likely does **not** bind a LatAm-incorporated company → Llama-lineage models are available, which
  unlocks the best narration fine-tunes (**Hermes 3, Euryale, Midnight Miqu** are Llama-lineage). The
  **700M-MAU cap** applies everywhere but is irrelevant until massive scale. Apache-2.0/MIT (Qwen,
  Mistral/Cydonia, GLM, DeepSeek, Gemma, MiniMax) remain the *cleanest* default for the reasoning seats,
  but Llama is no longer ruled out. **Not legal advice** — entity domicile vs the founder's operating
  location, and Brazil **LGPD** / Uruguay data-protection for user data, are questions for counsel.

## Latency / cost caveat (the 30s rule)

Reasoning models emit large chain-of-thought token volumes → slower and pricier per call. Decompose and
cognition are on the **critical path of every beat**, so don't put a heavy CoT model there; use a
**thinking-budget cap** or a non-reasoning mid model + constrained decoding. Reserve the heavy reasoner
for **resolve**, which fires only on uncertain actions.

## The hard line (domain-independent, non-negotiable)

The creative-writing community states the same baseline this product must enforce: **no minors, no
non-consensual depictions of real people.** This belongs in the **governance/classification gate**,
model-independent — permissive on adult content does **not** mean permissive here.
