# Actor — User (the player)

**Appears in:** steps 1, (5 as reader) · **Decisions:** A1, A6

## Role

Drives one character. Sends free text; receives narration. Authors **only their own character** — never
NPCs, never the world, never outcomes.

## What the user may do

- Send free text scoped to `(world, viewer)`.
- Optionally mark intent: `"speech"`, `*meta/expression/thought*`, or plain mixed prose (A1).
- Express **outer** actions (`*I scowl*`) that have consequences, including **performed/faked**
  expression (`*I scowl, hiding how rattled I am*`) — canon ≠ perception (A6).

## What the user may not do

- Author another actor's words, expression, or state (NPCs are not player-controlled — A6).
- Decide outcomes — intent is proposed; the engine resolves (D-1).
- Have their **inner** thoughts recorded — `*I don't trust her*` is sovereign and never stored (A6, B-4).

## What the user perceives

Only their own perception view (the wall, B-1/I-3). Narration renders the **perceived** world, which can
include performed expression or deception (the visible aspect, not the hidden canon truth).
