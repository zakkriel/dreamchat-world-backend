# Actor — World / NPCs (deferred subsystem)

**Appears in:** (not in the thin slice) · **Decisions:** A6 · **Defers to:** SPEC-012, SPEC-013

> Placeholder. The world/NPC actor is **not** in the Chunk-5 thin slice; this records its role so the
> loop docs are complete.

## Role (when built)

Autonomous agency in the world: scheduled world events and NPC behavior that fire as the clock advances.
Most are unwitnessed or non-disruptive; a perceived, expectation-breaking one is what stops a player's
chain (the world's source of pushback — capture §9 source (b)).

## Key boundaries (already decided)

- **NPC expression/behavior is never player-authored (A6).** "Kael looks annoyed" originates here as a
  **canon event**, generates the player's perception from its **visible** aspect, and is rendered by the
  narrator. Canon ≠ perception — an NPC can look annoyed without being annoyed.
- **Event-driven cognition (B-11).** NPCs update beliefs only when they *perceive* something, never on a
  free-running idle loop — every belief-update has a trigger and provenance.
- NPCs perceive through the **same wall** the player and narrator use (no omniscient NPCs).

## Deferred

The perceive → appraise → believe → decide → act loop (SPEC-012) and uncertain-outcome adjudication
(SPEC-013). Until then: no autonomous world activity; the turn-budget backstop is the only world-time
bound.
