# Step 6 — Return / response (hand the answer back)

**Driven by:** [Engine](../actors/engine-gate.md) · **Decisions:** —

> Not yet walked in depth — stub. Fill in when the review reaches it.

## What happens (overview)

The handler returns a single synchronous JSON body:

```json
{ "schema_version": "beat_result/1",
  "narration": "...",
  "result": { "committed": [...ids], "halt_reason": "...", "ticks_advanced": N } }
```

**No canon row crosses the boundary** (B-1) — only narration + a committed-event summary.

## Known divergence (to resolve)

`mvp_slice_and_bridge.md §4.2` specifies a **streamed SSE** write side — `POST /worlds/{w}/beats`
(plural) with interpretation/scene/aux/pushback/correction frames, plus `/beats/continue` and
`/corrections/...`. The shipped endpoint is `POST /worlds/{w}/beat` (singular), one sync JSON blob, none
of those frames. The two docs disagree on the wire contract; the frontend will codegen against one of
them. Candidate fix: an ADR recording sync `beat_result/1` as the thin-slice contract and the streamed
`/beats` shape as the deferred target (fires at the frontend play-surface build).

## Open (to detail later)

- Final response contract (sync vs streamed) and its `schema_version`.
- What `committed` summarizes without leaking canon.
