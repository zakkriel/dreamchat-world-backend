# Open Questions — Chunk 5.5 (kept alive)

> Live tracker so nothing gets quietly closed. Updated as we go. Decisions move to `decisions.md`;
> this is what's still open.

## Owed by Brian (content / north-star — not the agent's to invent)
- **Vertical slice:** what is Mara hiding (the canon fact + its visible aspect)?
- **Vertical slice:** what is the failable action (persuade / take / intimidate / other)?
- **Vertical slice:** what does Jonas do on his own (the one autonomous world event)?

## Pending confirmation (proposed, not locked)
- **A8 routing** by capability type — confirm?
- **Alive level for slice 1:** Level 2 (NPCs genuinely think) via a **single director LLM**, per-NPC
  perception-bound context, with the O-1 leak **tested** not assumed — confirm Level 2 over Level 1?
- **Price/cap:** €20 anchor (≈ €15 margin on mid open models, text only) — keep as working anchor?

## Decided — with downstream build work
- **Pod-or-no-pod → NO POD for Stage 0.** DeepInfra (and all major DeepSeek providers) do strict
  `json_schema` structured output on DeepSeek/Qwen via OpenAI-compatible API → the leash is available
  per-token. Stage 0 = **100% API, zero GPU**. Self-host returns only at the scale/sovereignty crossover.
- **A9 testing phasing** → build **constrained decoding** for decompose from day one (now satisfied by the
  host's `json_schema strict`); run an **early permissive narrate smoke-test**.
- **Self-hosting** → deferred; cost **and** content-sovereignty lever; named, not now.

## Flagged for counsel / separate track (not architecture)
- **Payment processor** — adult-content restrictions can hit the €20 revenue line (Stripe/PayPal risk;
  adult-friendly processors cost more).
- **Age verification / jurisdiction** — mandatory and tightening for adult platforms.
- **Entity** — Uruguay/Brazil domicile vs the founder's operating location; **LGPD** / data-protection
  for user data.
- **Hard line (non-negotiable, model-independent):** no minors, no non-consensual real-person
  depictions → enforced in the governance/classification gate.

## Resolved this session (for reference)
- META trace, speech addressing → A6 / A2.
- "One LLM per NPC" → retracted; one director, per-NPC context (A-discussion).
- Anthropic-only framing → corrected; permissive open-weight is the field.
- EU license assumption → corrected; LatAm entity, Llama-lineage available.
