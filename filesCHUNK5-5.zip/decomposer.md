# Actor — Decomposer (interpreter seat)

**Appears in:** step 3 · **Decisions:** A2, A3, A5, A6

## Role

Turns the player's prose into an **ordered chain of proposed events** from the closed vocabulary. The
input side of the loop's LLM. **Proposes only — never commits** (D-1).

## What it sees

Only the **perception payload** (the wall; B-1/I-3) — never canon, never another actor's view. Per A2,
that payload must become structured (location, co-present actors, reference-resolvable entities) so the
interpreter has handles to resolve against.

## Hard constraints

- **Closed vocabulary (the leash).** Constrained generation against `beat_chain/1`; out-of-vocabulary
  events are impossible by construction. `DecodeAndValidateChain` is the belt.
- **No identity-authority (A5).** Emits **reference tokens**, never raw ids. The engine binds
  token→id and rejects ambiguous/unknown refs.
- **No outcomes, no canon.** Emits intent; the gate resolves and commits.
- **Expression (A6).** Drops inner thoughts (never recorded); decomposes outer expression into a
  witnessed action event.

## Dependent on A3

Until generic `AttributeChanged` exists, the interpreter has only `move`/`say` to map onto — so rich
input is dropped or forced into two shapes. A3 is what gives this seat a real target vocabulary.
