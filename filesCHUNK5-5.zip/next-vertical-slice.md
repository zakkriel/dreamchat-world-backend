# Next Vertical Slice — "A Tavern That's Hiding Something"

**Status:** CONTENT LOCKED — 1c / 2c / 3c (2026-06-20) · **Decisions:** A7 (this is A7 made concrete) ·
**Pulls minimum slices of:** SPEC-012, SPEC-013, SPEC-016 + the step-5 narrate fix.

> This replaces "next we build SPEC-013, then SPEC-016, then SPEC-012" (horizontal, deferred) with **one
> playable scene** that contains the soul, built end to end and gated on whether it feels alive.

## The scene (one paragraph)

You walk into the **tavern**. **Mara** serves you like a stranger — but in *canon* she **knows exactly
who you are** and is pretending not to. As time passes, **Jonas** crosses the room, **slips Mara
something, and leaves on his own** — you may catch it or miss it. You try to **intimidate** her into
dropping the act — and it **can fail**: succeed and her composure cracks (the recognition surfaces);
fail and she holds the stranger act, now wary. The **narrator tells you what you saw** (a calm
stranger); **canon keeps what was real** (she knows you).

## What each beat must prove (the gate = experience, not CI)

| The soul | Minimum mechanism | Maps to |
|---|---|---|
| The world acts without you | one autonomous NPC event (Jonas leaves) fires as the clock advances; you may or may not witness it | SPEC-012 (min) |
| An action can fail | one **resolve** that returns outcome ≠ intent (refuse / partial + consequence) | SPEC-013 (min) |
| What happened ≠ what you saw | Mara has one attribute with a **visible** aspect ≠ **hidden** truth; perception surfaces the visible | SPEC-016 (min) |
| Pushback is felt, not just computed | the resolve outcome + `halt_reason` are **fed to the narrator** so the player is told | step-5 fix |
| Reference safety holds | the player's "her"/"the thing" resolves via token→id in the engine, not a model UUID | A5 |

**Done when:** you play it and (a) something happened you didn't cause, (b) something you tried didn't
just succeed, (c) you were shown an appearance that wasn't the truth, (d) the narrator communicated the
pushback — **and it made an interesting beat.** A green test suite is necessary but not sufficient.

## Deliberately still OUT (so the slice stays a slice)

A handful of NPCs at most (not 20); no NPC↔NPC perception; no cascade chains (SPEC-014); no spatial
engine (flat places, SPEC-018); no cost optimization. These are authoring/scale passes, taken **after**
the feel is proven (A7).

## Locked content (1c / 2c / 3c)

- **What Mara hides (1c):** she **recognizes the player** but **pretends not to**.
  - Hidden canon: `mara.recognizes_player = true`. Visible aspect: presents as a stranger.
  - *(North-star detail to flesh out later, not blocking: who the player is to her. The mechanism only
    needs "recognition = true, concealed.")*
- **Failable action (2c):** the player **intimidates** Mara.
  - Resolve (SPEC-013 min) adjudicates an uncertain outcome from state: **success** → her composure
    cracks, recognition surfaces (perception updates to match canon); **failure** → she holds the act
    and gains a consequence (wary / hostile / signals for help). Outcome ≠ intent.
- **Autonomous world event (3c):** **Jonas passes Mara something, then leaves**, fired on the clock —
  witnessed only if the player is co-present and attending.

### The interlock (why these three are better together, not just side by side)

- **Jonas's exit changes the odds.** Tie the intimidation resolve to state: with Jonas gone, Mara is
  isolated → more crackable; with him present, bolder. The world's autonomous action **materially
  affects** the player's resolution — "the world acted *and it mattered*," not two unrelated events.
- **The handoff is a discoverable clue.** What Jonas slips her can connect to why she's hiding —
  perceived if you watched, missed if you were busy intimidating. Tests perception-binding (you see only
  what you attended to).
- **Discovery cracks the lie through the mechanism, not a script.** Intimidation success surfaces the
  hidden `recognizes_player` via the **normal** perception update — no bespoke "reveal" branch. That's
  the canon ≠ perception mechanism proving itself, which is exactly the discriminating test (act off the
  authored path → if it still surfaces, it's real).

This is now an implementation plan (one worktree, one PR), built and judged as a **scene**, not as three
separate SPECs.
