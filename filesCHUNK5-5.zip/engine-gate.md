# Actor — Engine / Gate (the deterministic core)

**Appears in:** steps 2, 4, 6 · **Decisions:** A2, A3, A4, A5, A6

## Role

The deterministic spine: builds the perception payload, runs `apply_beat`, generates perceptions,
advances the clock, returns the result. It is the **only writer of canon** — the canonization point
(D-1). The LLM seats propose; the engine commits.

## The one non-perception-bound component

The decomposer and narrator read the player's partial view; **the engine reads objective canon.** That
asymmetry is the point of D-1 — a fallible model proposes, the component holding full truth decides. So
the engine can:
- reject proposals against real state the model never saw (move-validity, impossibility);
- commit **objective events**, from which perceptions are generated per-actor;
- inject the **visible-vs-hidden split** (A6 / SPEC-016) — it records both the truth and the appearance,
  so performed expression and deception live *in the world*, never in a lying seat.

## Responsibilities added by 5.5

- **A2** — produce the structured, perception-bound payload (still through the wall).
- **A5** — resolve reference token → id deterministically; reject unresolvable/ambiguous.
- **A4** — speech fan-out in `generate_perceptions`: default all co-present, whisper → addressed,
  state-excluded candidates filtered; `addressed_to` ≠ `heard_by`.
- **A6** — commit outer expression as a witnessed event; generate perceptions from the visible aspect.
- **A3** — branch on a small closed set built on generic `AttributeChanged`, not a growing verb list.

## Invariants it must keep

Append-only canon (B-5); deterministic replay (Q1/I-1); no perception leak (B-1/I-3); partial-beat
correctness (an interrupted chain never over-applies).
