# Step 4 — Apply / engine loop (`apply_beat`)

**Driven by:** [Engine / Gate](../actors/engine-gate.md) · **Decisions:** A3, A4, A5, A6

> Walked at overview level so far; to be detailed as the review reaches it.

## What happens

`apply_beat(world, viewer, chain, start_tick, tick_cap, origin)` is the **only canonization point**
(D-1). It runs the chain **incrementally**, four stages per event:

1. **(3a) Gate** — can it happen? Thin slice = co-location precondition (SPEC-017). Fail → **halt
   `gate_reject`**, nothing for this step commits.
2. **(3b) Resolve** — what actually happens. Thin slice = identity passthrough (adjudication deferred,
   SPEC-013).
3. **(3c) Apply + generate** — commit the accepted `canon_event` `(in_world_tick, beat_seq)`, write
   `state_mutation`, call `generate_perceptions`, advance the clock by the event's duration (ADR-036).
4. **(3d) Stop-check** — after a committed move, does a discovery break the next step's premise? →
   **halt `stop_check`** (the move stands, the rest never runs).

**Turn-budget backstop:** committed tick-delta over `tick_cap` → **halt `turn_budget`**.

### Halt reasons (the branches)

`completed` · `gate_reject` · `stop_check` · `turn_budget`.

### Partial-beat guarantee

A chain that halts at step k commits *exactly* the prefix and advances the clock by only the prefix
durations. Zero trace from the halt onward.

## Where the 5.5 decisions land here

- **A4 — speech fan-out** happens in `generate_perceptions`: default → all co-present; whisper →
  addressed; state-excluded candidates (deaf, etc.) filtered (rides on A3 attributes). `addressed_to` ≠
  `heard_by`.
- **A5 — id binding** happens *before* this step: the engine resolves the reference token → id and
  rejects unresolvable refs, so the gate only ever sees real ids.
- **A6 — outer expression** commits as a witnessed canon event and generates perceptions from its
  **visible** aspect; canon may differ (performed/faked expression) via the SPEC-016 split.
- **A3 — vocabulary** determines how many event types this loop must branch on; with generic
  `AttributeChanged` the per-type branches shrink to a small set.

## Runtime reality (observed 2026-06-20)

The **control flow is real** (incremental apply, two halts, partial-beat, action-driven clock). The
**content is largely stubbed** — consistent with "structure-in / behavior-deferred", but stated plainly
so it isn't mistaken for a working world:

- **Gate barely gates** — co-location only (SPEC-017 deferred); `move` is effectively ungated
  (`fn_move_duration` returns a flat `5` for any pair) → you can move to an unconnected place.
- **Resolve is a no-op** — outcome always = intent (SPEC-013 deferred); no failure-with-consequence.
- **The interrupt is one narrow case** — only a committed `move` → discovery breaking a queued `say`.
- **The world is frozen** — no NPC / scheduled / decay events fire in the gaps (SPEC-012/013 deferred);
  the clock advances into an empty world. "The world is alive" does not happen at runtime yet.
- **Durations are fake** — flat `5` / `0`; no topology or spatial derivation (SPEC-018 deferred).

These are documented deferrals, not new decisions — captured so the control-flow-vs-behavior gap is
explicit.

## Current vs intended

| | Shipped | Intended (5.5) |
|---|---|---|
| Event types handled | `move`, `say` | + generic `AttributeChanged` (A3); expression (A6) |
| Speech perception | addressed only | co-present fan-out + state filter (A4) |
| Ref binding | model passes UUID | engine binds token→id (A5) |
| Visible/hidden split | not present | available for expression/deception (A6 / SPEC-016) |
