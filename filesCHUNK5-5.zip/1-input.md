# Step 1 — Input (player sends text)

**Driven by:** [User](../actors/user.md) · **Decisions:** A1, A6

## What happens

The player sends `POST /worlds/{w}/beat` with a body of one field:

```json
{ "text": "whatever the player typed" }
```

Three things scope the request:
- **`{w}`** — world id, in the path. Dynamic; one backend serves many worlds.
- **viewer** — *who you are* in that world. Resolved **server-side** (the client cannot claim an
  identity). Debug honors `?viewer=`; otherwise it is derived.
- **`text`** — one free-text string. Nothing else on the body is read.

The request is **stateless**: no session, turn handle, or scene token. Every beat is an independent
POST; all prior state lives in the DB (canon + perceptions) and is reconstructed per call.

## Options the player has here

Free text, scoped to `(world, you)`. With the optional markup (A1):
- `"quotes"` → speech · `*asterisks*` → meta (expression/thought) · unmarked → mixed, still parsed.

There is intentionally **no** structured-action body, target selector, choice-pick, or attachment (A1
dropped the structured path).

## Expression at the input boundary (A6)

- **Inner thought** (`*I don't trust her*`) is sovereign and **not recorded** — the engine never stores
  the player's inner state.
- **Outer expression** (`*I scowl*`) is an **action**; it flows into the normal pipeline like any other.

## Current vs intended

| | Shipped | Intended (5.5) |
|---|---|---|
| Body | `{text}` only | unchanged |
| Markup | none (prose only) | `*meta*` / `"speech"` parsed (A1) |
| Structured action | absent | stays absent (A1) |
