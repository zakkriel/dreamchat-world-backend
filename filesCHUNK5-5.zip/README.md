# Chunk 5.5 — Loop Interaction

**Status:** LIVING — under active step-by-step review (started 2026-06-20)
**Intended repo location:** `docs/superpowers/specs/chunk-5.5-loop-interaction/`
**Amends:** Chunk-5 play loop (`2026-06-16-chunk-5-play-loop-architecture-notes.md`,
`2026-06-18-chunk-5-play-loop-backend.md`) and the write-side bridge contract
(`mvp_slice_and_bridge.md §4.2`). Nothing here touches the frozen engine canon.

> Supersedes the single-file draft `2026-06-20-chunk-5.5-input-and-flow-amendments.md`.

---

## ⮞ HEADLINE (read before slicing anything) — Decision A7

Prior chunks sliced **horizontally** (infra layers) and gated on **trust**, not experience — so dead
plumbing passed the gate it should have failed. **From here the unit of work is a vertical playable
scene that contains the soul**, and **"done" means it feels alive when played, not green CI.** Full
rationale + the "why not 20" answer in [`decisions.md` A7](decisions.md). The concrete next build is
[`next-vertical-slice.md`](next-vertical-slice.md).

---

---

## What this folder is

A walk of the play loop from **player input → answer**, one concern at a time, recording where the
shipped Chunk-5 backend matches intent and where it under-delivers. Findings become numbered
**Decisions** (`decisions.md`); each **step** and each **actor** has its own doc.

## The two registers (read this first)

The Chunk-5 capture talks on two levels; do not conflate them:
- **PROPOSED vocabulary (§2–3 of the capture)** — the target: six event types incl. a generic
  `AttributeChanged`. Marked *proposed*, to be filed as engine ADR(s) with running-code evidence.
- **Thin-slice action set (§7)** — what Chunk 5 was scoped to build: **`move` + `say` only**.

The shipped code matches the **thin slice**. Most findings here are about the gap between that floor
and the proposed target — see Decision A3.

## The loop at a glance

| # | Step | Driven by |
|---|------|-----------|
| 1 | [Input](steps/1-input.md) — player sends text | User |
| 2 | [Perception payload](steps/2-perception-payload.md) — gather what the viewer perceives | Engine (via the wall) |
| 3 | [Decompose](steps/3-decompose.md) — prose → ordered event chain | Decomposer |
| 4 | [Apply / engine loop](steps/4-apply-engine-loop.md) — gate → resolve → apply+generate → stop-check | Engine / Gate |
| 5 | [Narrate](steps/5-narrate.md) — render prose from the player's perceptions | Narrator |
| 6 | [Return / response](steps/6-return-response.md) — hand the answer back | Engine |

## Actors

- [User](actors/user.md) — the player; authors only their own character.
- [Decomposer](actors/decomposer.md) — interpreter seat; proposes only, perception-bound.
- [Engine / Gate](actors/engine-gate.md) — the deterministic core; the **only** canon writer.
- [Narrator](actors/narrator.md) — output seat; presentation only, perception-bound.
- [World / NPCs](actors/world-npcs.md) — deferred subsystem (SPEC-012/013); placeholder.

## Decisions

See [`decisions.md`](decisions.md) — the chronological log (A1–A10) with rationale. Step and actor docs
cite these IDs rather than repeating the reasoning. Live open threads:
[`open-questions.md`](open-questions.md).

## Build & infrastructure

- [`next-vertical-slice.md`](next-vertical-slice.md) — the agreed next build ("A Tavern That's Hiding
  Something"); content **locked** (1c/2c/3c).
- [`build-plan.md`](build-plan.md) — the implementation plan + agent handover for the slice (the **how**).
- [`model-survey.md`](model-survey.md) — per-seat model picks (reasoning vs prose; permissive; licenses).
- [`hosting-and-setup.md`](hosting-and-setup.md) — **Stage 0 = all-API, no pod**; scale/self-host path.
- [`runpod-stage0-runbook.md`](runpod-stage0-runbook.md) — **fallback** self-host runbook (only if a
  host's structured output / content policy fails).
- `dreamchat-cost-model.html` — interactive text+reasoning cost/margin model (in outputs root).
- [`HANDOVER-2026-06-20.md`](HANDOVER-2026-06-20.md) — self-contained session handover for a fresh agent.
