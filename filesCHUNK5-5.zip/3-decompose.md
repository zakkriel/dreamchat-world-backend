# Step 3 — Decompose (prose → ordered event chain)

**Driven by:** [Decomposer](../actors/decomposer.md) · **Decisions:** A3, A4, A5, A6

## What happens

The text + the perception payload (step 2) go to the `decompose` seat, which emits an **ordered chain**
of events from a **closed vocabulary**. Shipped vocabulary is exactly two types:

```json
[ {"type":"move","to":"square"},
  {"type":"say","listener":"<ref>","content":"..."} ]
```

Output is **proposed only** — the model never commits (D-1).

### How the vocabulary is enforced (two layers)

- **The leash (generation-time):** the seat *requires* a structured-output driver; generation is
  constrained to `beat_chain/1.schema.json`, so out-of-vocabulary types are impossible *by
  construction*. A driver that can't do this can't be bound to the seat (fails closed).
- **The belt (after):** `DecodeAndValidateChain` re-checks JSON + types + required fields; anything off
  → reject.

## The hard limits today (A3)

- **Two verbs, period.** "pick up", "attack", "search", "give" have no slot. This is because the
  **generic `AttributeChanged` keystone was not built** — see A3. Until it is, every new capability is a
  new type + new branch.
- **One linear chain, fixed order.** No branching/conditional/parallel.
- **Intent, not outcome.** The chain is *what you're trying to do*; success is decided later (step 4).

## Decisions that reshape this step

- **A5 — reference tokens, not raw ids.** The model must emit `listener` as a **reference token**
  (name/handle from the payload), **not** a UUID. The engine resolves it deterministically and rejects
  ambiguous/unresolvable refs. The model is never in identity-authority.
- **A4 — speech audibility.** The decomposer also captures **whisper vs not-whispered** from the prose
  /markup; the fan-out itself happens in step 4. Default not-whispered = heard by all co-present.
- **A6 — expression.** Inner thought (`*...*`) is dropped (never recorded). Outer expression
  (`*I scowl*`) is decomposed into a **witnessed action** event (lands in the closed set with A3).

## Current vs intended

| | Shipped | Intended (5.5) |
|---|---|---|
| Vocabulary | `move`, `say` (hardcoded) | closed set built on generic `AttributeChanged` (A3) |
| `listener` | raw UUID from model | reference token; engine binds (A5) |
| Speech reach | addressed only | co-present default; whisper narrows (A4) |
| Expression | no slot | outer = action; inner = dropped (A6) |
