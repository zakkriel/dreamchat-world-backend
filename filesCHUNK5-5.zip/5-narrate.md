# Step 5 — Narrate (render prose from the player's perceptions)

**Driven by:** [Narrator](../actors/narrator.md) · **Decisions:** A6

> Not yet walked in depth — stub. Fill in when the review reaches it.

## What happens (overview)

After the beat commits, the backend rebuilds the viewer's perception payload (post-beat) and hands it to
the `narrate` seat, which renders prose **from the player's perceptions only** (ADR-020, no omniscient
pass). Narration is **presentation, not canon** — never written to `canon_event` (I-6), not logged for
replay determinism.

## Carries forward

- **A6 — canon ≠ perception.** The narrator renders what the player *perceived*, which may be the
  **visible** aspect of a performed/faked expression or a deception — not the hidden canon truth.

## Open (to detail later)

- Exact post-beat payload contents handed to the narrator.
- Whether narration is session-logged for fidelity (separate from replay).
