# Decisions Log — Chunk 5.5 Loop Interaction

Chronological. Each decision has an ID, a status, the call, the why, and which step/actor docs it
touches. Step and actor docs cite these IDs.

---

## A1 — Input contract: free text with optional markup (drop the structured-action path)

**Status:** Decided · **Touches:** [step 1](steps/1-input.md), [user](actors/user.md), [decomposer](actors/decomposer.md)

- **Drop the structured-action input path.** `mvp_slice_and_bridge.md §4.2` defined the body as *"free
  text or structured action."* The structured alternative is dropped. Beat input is **free text only**.
- **Enable an optional in-text markup convention** the interpreter must understand — a *clarity tool*,
  never required syntax:
  - **`*asterisks*` → META** (thoughts, attitude, expression, emote). See A6 for how META is handled.
  - **`"quotes"` → SPEECH.**
  - **Unmarked prose → mixed.** Expression + speech + action can all arrive with no markers; the system
    must still parse them. Markers only *disambiguate* when the player chooses to use them.

---

## A2 — Enrich the interpreter context (the perception payload is too thin)

**Status:** Decided · **Touches:** [step 2](steps/2-perception-payload.md), [decomposer](actors/decomposer.md), [engine](actors/engine-gate.md)

**Finding.** The context handed to the interpreter is a flat list of prose strings
(`PerceptionPayload{ Lines []string }`). It carries no structured handles, so reference resolution and
addressing are guesswork: no entity ids to bind "her"/"the note" to, no co-presence list ("who can I
address"), no location/scene frame.

**Decision.** Widen the context to a **structured, still perception-bound payload** carrying at least:
the viewer's **current location**, the **co-present actors** (id + perceived name), and the **perceived
entities resolvable by reference** (id + perceived name + kind).

**Constraints.** Everything comes **through the wall** (perceived names via `fn_perceived_name`); never
raw canon; nothing unperceived leaks. Additive to the payload; the flat prose lines may remain as a
narrative channel.

---

## A3 — The closed-vocabulary keystone (generic `AttributeChanged`) is missing

**Status:** Decided (direction) · **Touches:** [step 3](steps/3-decompose.md), [step 4](steps/4-apply-engine-loop.md), [decomposer](actors/decomposer.md), [engine](actors/engine-gate.md)

**Finding.** The capture's core idea (§2) is that open language collapses onto a **small closed set of
state-deltas**, with a **generic `AttributeChanged`** (`entity.X = Y`) as the catch-all so *novelty
rides in data, not in new event types*. The shipped slice built only `move` + `say` as two hardcoded
`apply_beat` branches. **`AttributeChanged` — the keystone — was not built.**

**Consequence.** "Two verbs" is not the closed extensible spine. As shipped, every new capability = a
new event type + a new code branch — the "eternal enum" §2 set out to avoid. The trust guarantees
(replay / no-leak / partial-beat) are proven on move+say; **the §2 core realization is not proven.** It
is the same root as A1/A2: expression, possession, search, give have nowhere to land because the
catch-all does not exist.

**Direction.** Before adding more bespoke verbs, build **generic `AttributeChanged`** (carrying the
SPEC-016 visible-vs-hidden flag). Then move / say / expression / possession become *instances* of the
closed set rather than one-off branches.

---

## A4 — Speech audibility: co-presence + a state-gate, no spatial measurement

**Status:** Decided · **Touches:** [step 3](steps/3-decompose.md), [step 4](steps/4-apply-engine-loop.md), [engine](actors/engine-gate.md)

Shipped `say` (`private_disclosure`) perceives to the **addressed listener only** — wrong: speaking
aloud in a room is heard by everyone present. Fix, with **no acoustics and no distance math** (there
are no spatial references yet; co-presence is the only spatial fact):

- **Default (not whispered)** → every **co-present** actor receives it.
- **Whispered** → narrowed to the **addressed target(s)**.
- **Exclusion by state** → a co-present actor who *can't* receive it (deaf, unconscious, no shared
  language) is filtered out. This is a **gate / attribute check, handled later** (rides on A3); it is
  the only "can they hear it" logic and it is not spatial.
- **`addressed_to` ≠ `heard_by`** (whisper: addressed hears, bystanders don't).
- **Reach beyond the location** (a shout to the next room) is a spatial-engine concern (SPEC-018), not
  modelled now — within one location there is nowhere "further" to reach.

---

## A5 — Reference tokens, not raw ids (the model is never in identity-authority)

**Status:** Decided — MUST FIX · **Touches:** [step 3](steps/3-decompose.md), [decomposer](actors/decomposer.md), [engine](actors/engine-gate.md)

Today the interpreter emits a concrete `listener` **UUID** — i.e. the model resolves identity, and can
hallucinate an id or silently bind the **wrong** co-present actor. **Required:** the model emits a
**reference token** (a name/handle from the payload); the **engine** resolves token→id
**deterministically** and **rejects** anything unresolvable or ambiguous. Extends SPEC-015 to identity;
hallucinated / mis-bound ids become **structurally impossible**.

---

## A6 — Expression: INNER (sovereign, unrecorded) vs OUTER (an action)

**Status:** Decided · **Touches:** [step 1](steps/1-input.md), [step 3](steps/3-decompose.md), [step 4](steps/4-apply-engine-loop.md), [user](actors/user.md), [narrator](actors/narrator.md), [engine](actors/engine-gate.md)

- **Inner — `*I don't trust her*`:** a private thought. **Never recorded.** The engine does not author
  *or store* the player's inner state (B-4); the player's belief is theirs to hold, not ours to decide.
  It may color *this beat's own* narration; it is never written to canon or perception.
- **Outer — `*I scowl at her*`:** this **is an action** → through the gate → commits a **canon event**
  → generates perceptions for co-present witnesses → has consequences. Lands in the closed vocabulary as
  a witnessed event (exact type decided with A3).
- **Canon ≠ perception applies to expression.** An actor may *genuinely* scowl or *perform* one
  (visible aspect = scowl; hidden truth = amused) — the SPEC-016 visible/hidden split, the same
  machinery as any deception. Applies to the **player's own** character too
  (`*I scowl, hiding how rattled I am*`).
- **NPC expression is never player-authored.** "Kael looks annoyed" originates from Kael's *own*
  behavior as a canon event (NPC cognition, SPEC-012 — deferred); the perception is generated from its
  **visible** aspect, and the narrator renders the player's *perceived* version. The player only ever
  authors their own character.

---

## A7 — Methodology: slice vertically through the experience; gate on aliveness (HEADLINE)

**Status:** Decided — supersedes the horizontal-slice habit · **Touches:** everything

**The failure this corrects.** Prior chunks sliced **horizontally** (by infrastructure layer: replay,
no-leak, the clock) and the Chunk-5 product question (Q3) gated on **trust** — *"do the guarantees
survive an LLM in the loop?"* The capture explicitly made the experience ("the world evolves coherently,
the prose reads well") the **soft, non-gating** bar. So the one safeguard meant to stop dead plumbing
from shipping (the Validation Ladder's product-question rule) waved it through, because the world was
asked *"are you safe?"*, never *"are you alive?"*.

**The rule from here.** The unit of work is a **vertical playable scene that contains the soul**: one
place · NPC(s) that act on their own · an action that can fail · an expression that can be faked ·
narrated as *"what happened vs what you saw."* **"Done" = it feels alive when played, not green CI.** A
slice's product question must be an **experience** question, not an infrastructure question.

**Not a licence to build everything at once.** The slice stays bounded — but bounded by *experience*,
not by *layer*. This is the middle gear, not move-fast-break-everything.

**On scale (the "why not 20" answer).** The engine is content-agnostic: 1 NPC and 20 are the same code
path, so plurality does not prove the mechanism. Start with **enough to feel populated (a handful), few
enough to author and judge.** Going to 20 later is mostly **authoring + a cost/cascade pass**, not new
architecture. The genuinely new-at-scale problems — NPC↔NPC perception, cascade depth (SPEC-014),
per-turn cost — are real and **separate**; don't let them block proving the feel, and don't pretend
"one" was ever about proof.

→ The concrete next slice: [`next-vertical-slice.md`](next-vertical-slice.md).

---

## A8 — Per-seat routing by capability type

**Status:** Confirmed (host/model picks concretized in A10) · **Touches:** [decompose](actors/decomposer.md), [engine](actors/engine-gate.md), [narrate](actors/narrate.md) · see [`model-survey.md`](model-survey.md)

Route by capability **type**, not just cost. Reasoning family (Qwen3.5 / GLM-5 / DeepSeek-R1 /
Magistral) for **decompose + resolve**; prose/RP family (Hermes 3 / Euryale / Midnight Miqu / Cydonia)
for **narrate**; mid reasoning for **cognition**. All content-bearing seats use **permissive
open-weight** models (frontier refuses the material). Decompose's schema is enforced by **constrained
decoding at the host**, not model compliance. Heavy chain-of-thought reasoners go only on **resolve**
(off the every-beat path) to protect the 30s rule. License: Llama-lineage is OK for the LatAm entity;
Apache/MIT cleanest. *Not legal advice.*

## A9 — Phased testing: mechanics + aliveness clean first, explicit experience second (DECIDED)

**Status:** Decided · **Touches:** all · supersedes the earlier "frontier then migrate" framing

Three validation targets, not two: **(1) mechanics** (replay/no-leak/partial-beat, wiring,
perception-binding) — content-agnostic; **(2) aliveness** (world acts without you, what-happened ≠
what-you-saw, pushback) — **also content-agnostic**; **(3) explicit content quality** — needs permissive
models.

- **Phase 1:** validate (1)+(2) on **clean content** with frontier/fakes. Gate = "does it feel alive."
- **Phase 2:** swap to permissive models — **re-confirm model-driven quality** (decompose reliability,
  cognition/resolve, prose) **and** validate (3) the explicit experience.
- **Load-bearing distinction:** the **guarantees** transfer across models; the **model-driven quality**
  does not → phase 2 *re-confirms*, never *assumes*.
- **Insurance (build now):** constrained decoding for decompose from day one; one **early permissive
  narrate smoke-test** to de-risk the swap rather than saving it for a late "migration."

## A10 — Stage-0 hosting: 100% API, no pod (the structured-output leash is available per-token)

**Status:** Decided · **Touches:** [decompose](steps/3-decompose.md), [hosting](hosting-and-setup.md), [decomposer](actors/decomposer.md)

The only reason to self-host decompose was a guaranteed structured-output leash. That's now available via
permissive API: **DeepInfra serves strict `json_schema` (`response_format: json_schema, strict: true`)
on DeepSeek and Qwen**, OpenAI-compatible, and **all major DeepSeek providers support JSON mode**. So:

- **Stage 0 = 100% API, zero GPU.** Decompose → small Qwen (or DeepSeek) on DeepInfra with a strict
  schema; cognition/resolve → DeepSeek (chat for frequent, reasoning for rare resolve); narrate → RP
  model via OpenRouter permissive route.
- **Content policy is a NARRATE-only concern** — the other seats parse, they don't generate explicit
  prose. Verify the narrate route is permissive and the decompose host tolerates explicit input.
- **Cost** is fractions of a cent/beat; model **tier** dominates margin (~7×) far more than architecture
  (~1.5×). €20 anchor holds.
- **Self-host / pod / own-farm deferred** to the scale-or-sovereignty crossover. RunPod runbook =
  fallback. Building an own GPU farm was rejected (capex + German power + ops + idle burn; reserved cloud
  beats it until large, stable, high-utilization scale).
